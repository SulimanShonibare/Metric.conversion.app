package com.example.metricconversion

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.metricconversion.databinding.ActivityMainBinding



class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)
        setContentView(binding.root)
        binding.conversionTo.setOnClickListener { convertMetric() }

    }


    @SuppressLint("StringFormatMatches")
    fun convertMetric() {
        val stringInTextField = binding.howMuchStuffWeTalking.text.toString()
        val amountIQ = stringInTextField.toDouble()
        val selectedId = binding.unitThatNeedsToBeConverted.checkedRadioButtonId
        val selectedId2 = binding.toBeConverted.checkedRadioButtonId


        // code to convert grain to the other options

        //code to convert grain to the other options
       val conversion = when (selectedId to selectedId2) {
           R.id.Grain to R.id.Grain1 -> amountIQ
            R.id.Grain to R.id.Ounce1 -> amountIQ / 437.5
            R.id.Grain to  R.id. quarter1 -> amountIQ * 0.000005714
            R.id.Grain to  R.id.pound1 -> amountIQ * 0.0001429
            R.id.Grain to R.id.stone1 -> amountIQ * 0.0000102
            R.id.Grain to  R.id.Ton1 -> amountIQ / 1.4e+7
           R.id.Ounce to R.id.Ounce1 -> amountIQ
           R.id.Ounce to R.id.Grain1 -> amountIQ * 437.5
           R.id.Ounce to R.id.quarter1 -> amountIQ *0.0025
           R.id.Ounce to R.id.stone1 -> amountIQ * 0.005
           R.id.Ounce to R.id.pound1 -> amountIQ * 0.0625
           R.id.Ounce to R.id.Ton1 -> 0.0000283495
           R.id.quarter to R.id.Grain -> amountIQ * 175000
           R.id.quarter to R.id.Ounce1 -> amountIQ * 400
           R.id.quarter to R.id.quarter1-> amountIQ
           R.id.quarter to R.id.stone1 -> amountIQ * 2
           R.id.quarter to R.id.pound1 -> amountIQ * 25
           R.id.quarter to R.id.Ton1 -> amountIQ * 0.0113398093
           R.id.stone to R.id.Grain -> amountIQ * 87500
           R.id.stone to R.id.Ounce1 -> amountIQ * 200
           R.id.stone to R.id.quarter1 -> amountIQ * .5
           R.id.stone to R.id.stone1 -> amountIQ
           R.id.stone to R.id.pound1 -> amountIQ * 12.5
           R.id.stone to R.id.Ton1 -> amountIQ * 0.0056699046
           R.id.pound to R.id.pound1 -> amountIQ
           R.id.pound to R.id.Grain1 -> amountIQ * 7000
           R.id.pound to R.id.Ounce1 -> amountIQ * 16
           R.id.pound to R.id.Ton1 -> amountIQ * 0.0004535924
           R.id.Ton to R.id.Grain1 -> amountIQ * 15432358.353
           R.id.Ton to R.id.Ounce1 -> amountIQ * 35273.96195
           R.id.Ton to R.id.quarter1 -> amountIQ * 88.184904874
           R.id.Ton to R.id.stone1 -> amountIQ * 176.36980975
           R.id.Ton to R.id.pound1 -> amountIQ * 2204.6226218
           R.id.Ton to R.id.Ton1 -> amountIQ

           else-> error ("unsupported selection pair ")



        }



        binding.metricConverted.text=getString(R.string.end_result,conversion)

            }





        }


        /*when (selectedId and selectedId2) {
            R.id.Grain and R.id.pound1 -> amountIQ * 0.0001429
        }

        when (selectedId and selectedId2) {
            R.id.Grain and R.id.Ton1 -> amountIQ / 1.4e+7
        }
        when (selectedId and selectedId2) {
            st -> {
                amountIQ * 0.0000102
            }
        }


        val second = amountIQ * 0.000005714
        second)


    }
}
*/






/* val bs =when (selectedId ) {
            R.id.Grain and R.id.Ounce1 ->
                amountIQ




    }
        val bs2= when (selectedId and selectedId2) {
            grainToQtr -> amountIQ * 0.000005714
            else -> {}
        }

    }


}*/

// when (selectedId and selectedId2){
// R.id.Grain and R.id.quarter1 ->amountIQ * 0.000005714
//
// }
//
// when (selectedId and selectedId2){
// R.id.Grain and R.id.pound1 -> amountIQ * 0.0001429
// }
//
// when (selectedId and selectedId2){
// R.id.Grain and R.id.Ton1 -> amountIQ / 1.4e+7
// }
// when (selectedId and selectedId2){
// R.id.Grain and R.id.stone1-> {
// amountIQ * 0.0000102
// }
// }
//
//
//
// convertMetric()*\
//
//
//
//
//
//
//
//
//
//
//
// }
//
//
//
// }
//
// /*
//
//
//
//
// convertMetric()*/
// // binding.metricConverted.text = getString(R.string.end_result,convertMetric())
// // val grainToQtr = when (selectedId and selectedId2){
// // R.id.Grain and R.id.quarter1 -> amountIQ * 0.000005714
// //
// // else -> {}
// // }
// //
// //
// // binding.metricConverted.text=getString(R.string.end_result,grainToQtr)
// //
// // when (selectedId and selectedId2){
// // R.id.Grain and R.id.stone1-> {amountIQ * 0.0000102
// //
// // }
// // binding.metricConverted.text=getString(R.string.end_result,grainToSt)
// //
// // when (selectedId and selectedId2){
// // R.id.Grain and R.id.pound1 -> amountIQ * 0.0001429
// // }
// //
// // binding.metricConverted.text=getString(R.string.end_result,grainToLb)
// //
// //
// // val grainToTon = when (selectedId and selectedId2){
// // R.id.Grain and R.id.Ton1 -> amountIQ / 1.4e+7
// // else-> return
// // }
// // binding.metricConverted.text=getString(R.string.end_result,grainToTo




        /* convertMetric(){
             binding.metricConverted.text = getString(R.string.end_result,convertMetric())
             val grainToQtr = when (selectedId and selectedId2){
                 R.id.Grain and R.id.quarter1 -> amountIQ * 0.000005714

                 else -> {}
             }


             binding.metricConverted.text=getString(R.string.end_result,grainToQtr)

             when (selectedId and selectedId2){
                 R.id.Grain and R.id.stone1-> {amountIQ * 0.0000102

                 }
                 binding.metricConverted.text=getString(R.string.end_result,grainToSt)

                     when (selectedId and selectedId2){
                     R.id.Grain and R.id.pound1 -> amountIQ * 0.0001429
                 }

                 binding.metricConverted.text=getString(R.string.end_result,grainToLb)


                     val grainToTon = when (selectedId and selectedId2){
                     R.id.Grain and R.id.Ton1 -> amountIQ / 1.4e+7
                     else-> return
                 }
                 binding.metricConverted.text=getString(R.string.end_result,grainToTo


             }*/